# 🚀 Guía Rápida: Sistema de Feed para Frontend

## 📡 URLs Base del API
```
Desarrollo: http://localhost:3001/api/v1
Producción: https://tu-dominio.com/api/v1
```

## 🎯 Cambios Principales

### ✅ Lo que YA funciona (sin cambios)
- `GET /api/v1/feed` - Todo el contenido (noticias + comunidad)
- `GET /api/v1/feed/noticias` - Solo noticias
- `GET /api/v1/feed/comunidad` - Solo comunidad
- `GET /api/v1/feed/stats` - Estadísticas del feed

### 🆕 NUEVO: Likes y Comentarios Universales

**IMPORTANTE**: Ahora likes y comentarios funcionan para **TODO** tipo de contenido usando el **`feedId`** (ID de `content_feed`).

#### ✅ Dar Like (funciona para noticias Y comunidad)
```javascript
// POST /api/v1/feed/:feedId/like
const darLike = async (feedId) => {
  await axios.post(`/api/v1/feed/${feedId}/like`, {}, {
    headers: { Authorization: `Bearer ${token}` }
  });
};
```

#### ✅ Quitar Like
```javascript
// DELETE /api/v1/feed/:feedId/like
const quitarLike = async (feedId) => {
  await axios.delete(`/api/v1/feed/${feedId}/like`, {
    headers: { Authorization: `Bearer ${token}` }
  });
};
```

#### ✅ Crear Comentario (funciona para noticias Y comunidad)
```javascript
// POST /api/v1/feed/:feedId/comments
const crearComentario = async (feedId, contenido) => {
  await axios.post(`/api/v1/feed/${feedId}/comments`, 
    { content: contenido },
    { headers: { Authorization: `Bearer ${token}` } }
  );
};
```

#### ✅ Obtener Comentarios
```javascript
// GET /api/v1/feed/:feedId/comments
const obtenerComentarios = async (feedId) => {
  const response = await axios.get(`/api/v1/feed/${feedId}/comments`);
  return response.data; // Array de comentarios
};
```

## 🔧 Implementación en Componentes

### Ejemplo: Componente FeedItem.vue

```vue
<template>
  <div class="feed-item">
    <h3>{{ item.titulo }}</h3>
    <p>{{ item.descripcion }}</p>
    
    <!-- Botones de Like y Comentarios -->
    <div class="feed-actions">
      <button @click="toggleLike" :class="{ liked: userHasLiked }">
        ❤️ {{ item.likes_count }}
      </button>
      
      <button @click="toggleComments">
        💬 {{ item.comments_count }}
      </button>
    </div>

    <!-- Sección de comentarios (si está expandida) -->
    <div v-if="showComments" class="comments-section">
      <div v-for="comment in comments" :key="comment.id" class="comment">
        <strong>{{ comment.autor }}:</strong> {{ comment.content }}
      </div>
      
      <div class="new-comment">
        <input v-model="newComment" placeholder="Escribe un comentario..." />
        <button @click="addComment">Enviar</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useAuthStore } from '@/stores/auth';
import { feedService } from '@/services/feedService';

const props = defineProps(['item']);
const authStore = useAuthStore();

const userHasLiked = ref(false); // Implementar lógica según tu estado
const showComments = ref(false);
const comments = ref([]);
const newComment = ref('');

const toggleLike = async () => {
  try {
    if (userHasLiked.value) {
      await feedService.quitarLike(props.item.id); // item.id es el feedId
      props.item.likes_count--;
      userHasLiked.value = false;
    } else {
      await feedService.darLike(props.item.id);
      props.item.likes_count++;
      userHasLiked.value = true;
    }
  } catch (error) {
    console.error('Error al dar like:', error);
  }
};

const toggleComments = async () => {
  showComments.value = !showComments.value;
  
  if (showComments.value && comments.value.length === 0) {
    try {
      comments.value = await feedService.obtenerComentarios(props.item.id);
    } catch (error) {
      console.error('Error al cargar comentarios:', error);
    }
  }
};

const addComment = async () => {
  if (!newComment.value.trim()) return;
  
  try {
    await feedService.crearComentario(props.item.id, newComment.value);
    // Recargar comentarios
    comments.value = await feedService.obtenerComentarios(props.item.id);
    props.item.comments_count++;
    newComment.value = '';
  } catch (error) {
    console.error('Error al crear comentario:', error);
  }
};
</script>
```

### Servicio de Feed (feedService.js)

```javascript
// services/feedService.js
import axios from 'axios';

const API_BASE = '/api/v1';

export const feedService = {
  // Obtener feed
  async getFeed(params = {}) {
    const response = await axios.get(`${API_BASE}/feed`, { params });
    return response.data;
  },

  async getNoticias(params = {}) {
    const response = await axios.get(`${API_BASE}/feed/noticias`, { params });
    return response.data;
  },

  async getComunidad(params = {}) {
    const response = await axios.get(`${API_BASE}/feed/comunidad`, { params });
    return response.data;
  },

  // Likes (NUEVO - funciona para TODO)
  async darLike(feedId) {
    await axios.post(`${API_BASE}/feed/${feedId}/like`);
  },

  async quitarLike(feedId) {
    await axios.delete(`${API_BASE}/feed/${feedId}/like`);
  },

  // Comentarios (NUEVO - funciona para TODO)
  async crearComentario(feedId, content) {
    const response = await axios.post(`${API_BASE}/feed/${feedId}/comments`, { content });
    return response.data;
  },

  async obtenerComentarios(feedId) {
    const response = await axios.get(`${API_BASE}/feed/${feedId}/comments`);
    return response.data;
  },

  // Estadísticas
  async getStats() {
    const response = await axios.get(`${API_BASE}/feed/stats`);
    return response.data;
  }
};
```

## 🔑 Puntos Clave para el Frontend

### 1. **feedId es la clave**
```javascript
// ✅ CORRECTO: Usar item.id (feedId de content_feed)
await feedService.darLike(item.id);

// ❌ INCORRECTO: No usar original_id
// await feedService.darLike(item.original_id);
```

### 2. **Mismo código para noticias y comunidad**
```javascript
// Funciona igual para type=1 (noticias) y type=2 (comunidad)
const manejarLike = async (feedItem) => {
  await feedService.darLike(feedItem.id); // Sin importar el tipo
};
```

### 3. **Estructura de respuesta del feed**
```javascript
{
  "data": [
    {
      "id": 123,              // ← Este es el feedId que necesitas
      "type": 1,              // 1=noticia, 2=comunidad
      "original_id": 456,     // ID en tabla original (no usar para likes/comments)
      "titulo": "...",
      "likes_count": 15,      // Precalculado
      "comments_count": 8,    // Precalculado
      // ... otros campos
    }
  ],
  "pagination": { ... }
}
```

### 4. **Manejo de errores**
```javascript
try {
  await feedService.darLike(feedId);
} catch (error) {
  if (error.response?.status === 400) {
    // Ya se dio like
    console.log('Ya has dado like a este elemento');
  } else if (error.response?.status === 401) {
    // No autenticado - redirigir a login
    router.push('/login');
  }
}
```

## 🚨 Headers Requeridos

```javascript
// Para likes y comentarios
headers: {
  'Authorization': `Bearer ${token}`,
  'Content-Type': 'application/json' // Solo para POST con body
}
```

## 📋 Checklist de Migración

- [ ] Actualizar `feedService.js` con nuevos métodos
- [ ] Cambiar calls de likes de `/news/:id/like` a `/feed/:feedId/like`
- [ ] Cambiar calls de comentarios de `/news/:id/comments` a `/feed/:feedId/comments`
- [ ] Usar `item.id` (feedId) en lugar de `item.original_id`
- [ ] Probar likes en contenido de comunidad (type=2)
- [ ] Probar comentarios en contenido de comunidad (type=2)
- [ ] Verificar que conteos se actualizan automáticamente

## 🎉 Beneficios

- ✅ **Una sola API** para likes/comentarios (noticias + comunidad)
- ✅ **Código más simple** - no necesitas distinguir tipos
- ✅ **Conteos automáticos** - `likes_count` y `comments_count` siempre actualizados
- ✅ **Mejor performance** - menos consultas, datos precalculados
- ✅ **Experiencia consistente** para usuarios

---

**¿Dudas?** El backend maneja automáticamente qué tabla usar según el tipo de contenido. Tu frontend solo necesita usar el `feedId` y las nuevas rutas. ¡Es así de simple! 🚀 