const bcrypt = require('bcrypt');
const mysql = require('mysql2/promise');
require('dotenv').config();

async function createAdminUser() {
  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'cdelu_diario'
  });

  try {
    console.log('🔗 Conectando a la base de datos...');
    
    // Crear la tabla de roles si no existe
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS roles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(50) NOT NULL UNIQUE
      )
    `);

    // Insertar roles si no existen
    await connection.execute(`
      INSERT IGNORE INTO roles (nombre) VALUES 
      ('administrador'),
      ('colaborador'),
      ('usuario')
    `);

    // Crear la tabla de usuarios si no existe
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role_id INT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (role_id) REFERENCES roles(id)
      )
    `);

    // Hash de la contraseña
    const password = 'w35115415';
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    console.log('🔐 Generando hash de contraseña...');

    // Insertar o actualizar el usuario administrador
    const [result] = await connection.execute(`
      INSERT INTO users (nombre, email, password, role_id)
      VALUES (?, ?, ?, (SELECT id FROM roles WHERE nombre = 'administrador'))
      ON DUPLICATE KEY UPDATE
        password = VALUES(password),
        role_id = VALUES(role_id)
    `, ['Matias Moreira', 'matias4315@gmail.com', hashedPassword]);

    if (result.affectedRows > 0) {
      console.log('✅ Usuario administrador creado/actualizado exitosamente!');
      console.log('📧 Email: matias4315@gmail.com');
      console.log('🔑 Contraseña: w35115415');
      console.log('👤 Rol: Administrador');
    } else {
      console.log('⚠️ No se pudo crear/actualizar el usuario');
    }

  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error('💡 Asegúrate de que:');
    console.error('   1. La base de datos existe');
    console.error('   2. Las credenciales en .env son correctas');
    console.error('   3. MySQL está corriendo');
  } finally {
    await connection.end();
  }
}

// Ejecutar el script
createAdminUser(); 