const fastify = require('fastify')({ logger: true });
const path = require('path');
const config = require('./config/default');
const featureNewsRoutes = require('./features/news/news.routes');
const featureAuthRoutes = require('./features/auth/auth.routes');
const userRoutes = require('./routes/users');
const statsRoutes = require('./routes/stats');
const comRoutes = require('./routes/com.routes.js');
const docsRoutes = require('./routes/docs.routes.js');
const feedRoutes = require('./routes/feed.routes.js');
const mobileRoutes = require('./routes/mobile.routes.js');
const featureAdsRoutes = require('./features/ads/ads.routes');
const lotteryRoutes = require('./routes/lottery.routes.js');
const featureSurveysRoutes = require('./features/surveys/surveys.routes');
const featureFacebookRoutes = require('./features/facebook/facebook.routes');
const featureUsersRoutes = require('./features/users/users.routes');
const adminRoutes = require('./routes/admin.routes.js');
const profileRoutes = require('./routes/profile.routes.js');
const { authenticate, authorize } = require('./middlewares/auth');

// Registrar plugins
// Seguridad básica HTTP headers (relajar políticas para permitir imágenes cross-origin en dev)
fastify.register(require('@fastify/helmet'), {
  contentSecurityPolicy: false,
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  crossOriginEmbedderPolicy: false,
});

// Cache-Control para estáticos: 7 días (producción) / 0 (desarrollo)
const isProd = (process.env.NODE_ENV === 'production');
fastify.addHook('onSend', async (request, reply, payload) => {
  if (request.raw.url && (request.raw.url.startsWith('/public/') || request.raw.url.endsWith('.html'))) {
    const maxAge = isProd ? 7 * 24 * 60 * 60 : 0;
    reply.header('Cache-Control', `public, max-age=${maxAge}`);
  }
  return payload;
});
fastify.register(require('@fastify/cors'), {
  origin: config.corsOrigin,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'HEAD', 'PATCH'],
  allowedHeaders: [
    'Content-Type', 
    'Authorization', 
    'X-Requested-With',
    'Accept',
    'Origin',
    'Access-Control-Request-Method',
    'Access-Control-Request-Headers',
    'User-Agent',
    'Cache-Control',
    'Pragma'
  ],
  exposedHeaders: [
    'X-API-Version',
    'X-Response-Time',
    'X-Total-Count',
    'X-Auth-Token',
    'X-User-Id'
  ],
  optionsSuccessStatus: 200,
  preflightContinue: false,
  // Configuración específica para apps móviles
  maxAge: 86400, // Cache preflight por 24 horas
  allowCredentials: true
});

// Registrar plugin JWT
fastify.register(require('@fastify/jwt'), {
  secret: config.jwt.secret,
  sign: {
    expiresIn: config.jwt.expiresIn
  }
});

// Registrar Rate Limiting - CRÍTICO para seguridad
const { registerRateLimit } = require('./middlewares/rateLimit');
registerRateLimit(fastify);

// Registrar plugin para servir archivos estáticos
fastify.register(require('@fastify/static'), {
  root: path.join(__dirname, '..', 'public'),
  prefix: '/public/',
  decorateReply: false,
  index: false, // No servir index.html automáticamente
  list: false   // No listar directorios
});

// Registrar plugin para servir archivos estáticos en la raíz
fastify.register(require('@fastify/static'), {
  root: path.join(__dirname, '..', 'public'),
  prefix: '/',
  decorateReply: false,
  index: false,
  list: false
});

// Registrar Swagger para documentación de API
fastify.register(require('@fastify/swagger'), {
  openapi: {
    info: {
      title: 'CdelU API',
      description: 'API REST para el diario online CdelU - Portal de noticias con autenticación JWT y gestión de contenido multimedia',
      version: '1.0.0',
      contact: {
        name: 'Equipo de Desarrollo CdelU',
        email: 'dev@cdelu.ar'
      }
    },
    servers: [
      {
        url: process.env.NODE_ENV === 'production' 
          ? 'https://api.cdelu.ar' 
          : 'http://localhost:3001',
        description: process.env.NODE_ENV === 'production' 
          ? 'Servidor de Producción (cdelu.ar)' 
          : 'Servidor de Desarrollo'
      }
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'Token JWT obtenido tras el login. Formato: Bearer <token>'
        },
        apiKeyAuth: {
          type: 'apiKey',
          in: 'header',
          name: 'x-api-key',
          description: 'API Key para acceso externo. Enviar en header X-API-Key'
        }
      }
    },
    security: [
      {
        bearerAuth: []
      }
    ],
    tags: [
      { name: 'Autenticación', description: 'Endpoints para login y registro' },
      { name: 'Noticias', description: 'Gestión de noticias y contenido' },
      { name: 'Usuarios', description: 'Gestión de usuarios y perfiles' },
      { name: 'Estadísticas', description: 'Métricas y estadísticas del sistema' },
      { name: 'Comunicaciones', description: 'Sistema de comunicaciones multimedia' },
      { name: 'Feed', description: 'Feed unificado de contenido (noticias y comunidad)' },
      { name: 'Documentación', description: 'Endpoints de documentación interna' },
      { name: 'Facebook Live', description: 'Estado del Live de Facebook y reproducción embebida' }
    ]
  },
  hideUntagged: true,
  exposeRoute: true
});

// Registrar Swagger UI
fastify.register(require('@fastify/swagger-ui'), {
  routePrefix: '/api/v1/docs',
  uiConfig: {
    docExpansion: 'list',
    deepLinking: false,
    displayOperationId: false,
    defaultModelsExpandDepth: 1,
    defaultModelExpandDepth: 1,
    displayRequestDuration: true,
    docExpansion: 'none',
    filter: true,
    maxDisplayedTags: 10,
    showExtensions: false,
    showCommonExtensions: false,
    tryItOutEnabled: true
  },
  uiHooks: {
    onRequest: function (request, reply, next) { next() },
    preHandler: function (request, reply, next) { next() }
  },
  staticCSP: true,
  transformSpecificationClone: true
});

// Registrar fastify/multipart para subida de archivos
fastify.register(require('@fastify/multipart'), {
  attachFieldsToBody: true,
  limits: {
    fieldNameSize: 100,        // Max field name size in bytes
    fieldSize: 1024 * 1024 * 1,  // Max field value size in bytes (1MB para campos de texto)
    fields: 10,                // Max number of non-file fields
    fileSize: 1024 * 1024 * 200, // Max file size in bytes (200MB por archivo)
    files: 7,                  // Max number of file fields (ej. 1 video + 6 imagenes)
    headerPairs: 2000          // Max number of header key=>value pairs
  }
});

// Ruta de health check - DEBE estar antes del hook onRequest
fastify.get('/health', {
  schema: {
    tags: ['Sistema'],
    summary: 'Health Check del servidor',
    description: 'Endpoint para verificar que el servidor está funcionando correctamente',
    response: {
      200: {
        description: 'Servidor funcionando correctamente',
        type: 'object',
        properties: {
          status: { type: 'string' },
          timestamp: { type: 'string', format: 'date-time' },
          uptime: { type: 'number', description: 'Tiempo de actividad en segundos' },
          environment: { type: 'string', description: 'Entorno de ejecución' }
        }
      }
    }
  }
}, async (request, reply) => {
  return { 
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development'
  };
});

// DEBUG: Verificar variables de entorno
fastify.get('/debug/env', async (request, reply) => {
  const config = require('./config/default');
  return {
    timestamp: new Date().toISOString(),
    env: {
      API_KEY: process.env.API_KEY ? 'SET (' + process.env.API_KEY.substring(0, 10) + '...)' : 'NOT SET',
      NODE_ENV: process.env.NODE_ENV,
      PORT: process.env.PORT
    },
    config: {
      apiKey: config.apiKey ? 'SET (' + config.apiKey.substring(0, 10) + '...)' : 'NOT SET'
    }
  };
});

// GET /api/v1/modules/config - Estado público de módulos (sin autenticación)
fastify.get('/api/v1/modules/config', async (request, reply) => {
  try {
    const pool = require('./config/database');
    
    // Auto-create and seed if needed
    await pool.query(`
      CREATE TABLE IF NOT EXISTS system_modules (
        id INT AUTO_INCREMENT PRIMARY KEY,
        module_name VARCHAR(50) NOT NULL UNIQUE,
        display_name VARCHAR(100) NOT NULL,
        description VARCHAR(255),
        enabled BOOLEAN NOT NULL DEFAULT TRUE,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    await pool.query(`
      INSERT IGNORE INTO system_modules (module_name, display_name, description, enabled) VALUES
        ('ads',       'Publicidad',  'Banners y anuncios publicitarios en el sitio', TRUE),
        ('lotteries', 'Sorteos',     'Sistema de sorteos y venta de tickets',        TRUE),
        ('surveys',   'Encuestas',   'Módulo de encuestas y votaciones',             TRUE),
        ('facebook',  'Facebook',    'Widget y login con Facebook',                  TRUE),
        ('community', 'Comunidad',   'Feed y publicaciones de la comunidad',         TRUE)
    `);

    const [rows] = await pool.query('SELECT module_name, enabled FROM system_modules');
    
    // Return flat map: { ads: true, lotteries: false, ... }
    const config = {};
    rows.forEach(r => { config[r.module_name] = Boolean(r.enabled); });

    // Short cache — 5 minutes — helps frontend perf without being stale too long
    reply.header('Cache-Control', 'public, max-age=300');
    reply.send({ success: true, modules: config });
  } catch (error) {
    console.error('Error fetching modules config:', error);
    // On DB error, default to all modules enabled (fail-open)
    reply.send({ 
      success: true, 
      modules: { ads: true, lotteries: true, surveys: true, facebook: true, community: true }
    });
  }
});

// Ruta para favicon (evita 404 en logs) - DEBE estar antes del hook onRequest
fastify.get('/favicon.ico', async (request, reply) => {
  return reply.code(204).send();
});

// Ruta para robots.txt (evita 404 en logs)
fastify.get('/robots.txt', async (request, reply) => {
  reply.type('text/plain');
  return `User-agent: *
Disallow: /api/
Allow: /public/`;
});

// Ruta de diagnóstico para cPanel
fastify.get('/api/v1/status', {
  schema: {
    tags: ['Sistema'],
    summary: 'Estado detallado del sistema',
    description: 'Endpoint para diagnosticar problemas en cPanel',
    response: {
      200: {
        description: 'Estado del sistema',
        type: 'object',
        properties: {
          status: { type: 'string' },
          timestamp: { type: 'string', format: 'date-time' },
          uptime: { type: 'number' },
          environment: { type: 'string' },
          database: { type: 'object' },
          memory: { type: 'object' }
        }
      }
    }
  }
}, async (request, reply) => {
  const pool = require('./config/database');
  let dbStatus = 'disconnected';
  let dbError = null;
  
  try {
    const connection = await pool.getConnection();
    await connection.ping();
    connection.release();
    dbStatus = 'connected';
  } catch (error) {
    dbError = error.message;
  }
  
  const memory = process.memoryUsage();
  
  return { 
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    database: {
      status: dbStatus,
      error: dbError
    },
    memory: {
      rss: `${Math.round(memory.rss / 1024 / 1024)} MB`,
      heapTotal: `${Math.round(memory.heapTotal / 1024 / 1024)} MB`,
      heapUsed: `${Math.round(memory.heapUsed / 1024 / 1024)} MB`
    }
  };
});

// Registrar rutas
// Auth feature-based (evitar duplicar rutas con legacy)
fastify.register(featureAuthRoutes);
// Rutas feature-based (mismo path /api/v1/news, controlador/servicio desacoplados)
fastify.register(featureNewsRoutes);
fastify.register(userRoutes);
fastify.register(statsRoutes);
fastify.register(comRoutes);
fastify.register(docsRoutes);
fastify.register(feedRoutes);
fastify.register(mobileRoutes);
// Rutas Ads feature-based
fastify.register(featureAdsRoutes);
// Facebook Live
fastify.register(featureFacebookRoutes);
// Rutas Users feature-based (perfiles públicos y seguimiento)
fastify.register(featureUsersRoutes);
fastify.register(lotteryRoutes);
// Reemplaza rutas legacy de encuestas por feature-based
fastify.register(featureSurveysRoutes);
fastify.register(adminRoutes);
fastify.register(profileRoutes, { prefix: '/api/v1/profile' });

// Ruta específica para el dashboard (opcional)
fastify.get('/dashboard', async (request, reply) => {
  return reply.sendFile('dashboard.html');
});

// Ruta para la raíz que redirija al dashboard
fastify.get('/', async (request, reply) => {
  return reply.redirect('/dashboard.html');
});

// Hook para headers globales
fastify.addHook('onRequest', async (request, reply) => {
    // Agregar headers específicos para apps móviles
    reply.header('X-API-Version', '1.0.0');
    reply.header('X-Response-Time', Date.now());
    
    // Headers para CORS específicos de apps móviles
    if (request.headers.origin) {
        reply.header('Access-Control-Allow-Origin', request.headers.origin);
    }
    reply.header('Access-Control-Allow-Credentials', 'true');
});

// Manejador de errores global mejorado
fastify.setErrorHandler((error, request, reply) => {
  // Registrar el error con todos los detalles
  request.log.error({
    error: error,
    message: error.message,
    stack: error.stack,
    url: request.url,
    method: request.method,
    params: request.params,
    query: request.query,
    headers: request.headers,
    timestamp: new Date().toISOString()
  });
  
  // Error de validación
  if (error.validation) {
    return reply
      .code(400)
      .send({ 
        error: 'Error de validación', 
        message: 'Los datos enviados no cumplen con el formato requerido',
        details: error.validation,
        code: 'VALIDATION_ERROR'
      });
  }

  // Error de JWT
  if (error.code === 'FST_JWT_NO_AUTHORIZATION_IN_HEADER' || 
      error.code === 'FST_JWT_AUTHORIZATION_TOKEN_EXPIRED' ||
      error.code === 'FST_JWT_AUTHORIZATION_TOKEN_INVALID') {
    return reply
      .code(401)
      .send({ 
        error: 'No autorizado', 
        message: 'Token inválido o expirado. Por favor inicie sesión nuevamente.',
        code: 'JWT_ERROR'
      });
  }

  // Error de base de datos
  if (error.code && error.code.startsWith('ER_')) {
    return reply
      .code(500)
      .send({ 
        error: 'Error de base de datos', 
        message: 'Ocurrió un problema con la conexión a la base de datos.',
        code: error.code
      });
  }

  // Error de conexión a base de datos
  if (error.code === 'ECONNREFUSED' || error.code === 'ETIMEDOUT' || error.code === 'PROTOCOL_CONNECTION_LOST') {
    return reply
      .code(503)
      .send({ 
        error: 'Base de datos no disponible', 
        message: 'No se pudo conectar a la base de datos. Por favor intente más tarde.',
        code: 'DATABASE_UNAVAILABLE'
      });
  }

  // Error de multipart/upload
  if (error.code === 'FST_REQ_FILE_TOO_LARGE') {
    return reply
      .code(413)
      .send({
        error: 'Archivo demasiado grande',
        message: 'El archivo excede el tamaño máximo permitido (200MB).',
        code: 'FILE_TOO_LARGE'
      });
  }

  // Error de rate limiting (si se implementa)
  if (error.statusCode === 429) {
    const retrySeconds = Number(error.retryAfter || 900);
    reply.header('Retry-After', retrySeconds.toString());
    return reply
      .code(429)
      .send({ 
        error: 'Demasiadas solicitudes', 
        message: 'Ha excedido el límite de solicitudes. Intente nuevamente más tarde.',
        retryAfter: retrySeconds,
        code: 'RATE_LIMIT_EXCEEDED'
      });
  }

  // Error genérico pero con información de diagnóstico
  const statusCode = error.statusCode || 500;
  
  reply
    .code(statusCode)
    .send({ 
      error: 'Error en el servidor', 
      message: error.message, // Mostrar el error real para diagnosticarlo
      code: 'INTERNAL_SERVER_ERROR',
      timestamp: new Date().toISOString()
    });
});

// Hook para añadir headers de respuesta
fastify.addHook('onSend', async (request, reply, payload) => {
  // Añadir header de versión de API
  reply.header('X-API-Version', '1.0.0');
  
  // Añadir header de tiempo de procesamiento
  const responseTime = Date.now() - request.startTime;
  reply.header('X-Response-Time', `${responseTime}ms`);
  
  return payload;
});

// Hook para medir tiempo de respuesta
fastify.addHook('onRequest', async (request, reply) => {
  request.startTime = Date.now();
});

module.exports = fastify; 