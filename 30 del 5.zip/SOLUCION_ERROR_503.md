# 🚨 SOLUCIÓN PARA ERROR 503 EN CPANEL (PASSENGER)

## Problema actual
Tu aplicación está mostrando errores 503 (Service Unavailable) y 500 (Internal Server Error). **Tu hosting tiene Passenger configurado**, lo cual es excelente, pero necesitamos verificar la configuración.

## ✅ PASOS PARA SOLUCIONAR CON PASSENGER

### 1. Verificar configuración de Passenger
Tu `.htaccess` muestra que tienes **CloudLinux Passenger** configurado:
- ✅ **Directorio**: `/home/trigamer/diario.trigamer.xyz`
- ✅ **Node.js**: Versión 20 
- ✅ **Archivo de inicio**: `passenger_app.js`

### 2. Ejecutar diagnóstico específico de Passenger
Sube todos los archivos al servidor y ejecuta:
```bash
node check_passenger_status.js
```
Este script verificará específicamente la configuración de Passenger.

### 3. Configurar variables de entorno en cPanel
1. Ve a **cPanel > Setup Node.js App**
2. Busca tu aplicación `diario.trigamer.xyz`
3. Haz clic en **"Edit"** o **"Editar"**
4. En la sección **"Environment Variables"**, añade:

```
NODE_ENV=production
DB_HOST=localhost
DB_USER=tu_usuario_mysql
DB_PASSWORD=tu_contraseña_mysql
DB_NAME=tu_base_datos
JWT_SECRET=clave_secreta_muy_segura
CORS_ORIGIN=https://diario.trigamer.xyz
PORT=3001
```

### 4. Verificar configuración de la aplicación Node.js
En **cPanel > Setup Node.js App**, asegúrate de que esté configurado así:
- **Directorio de la aplicación**: `/home/trigamer/diario.trigamer.xyz`
- **Archivo de inicio**: `passenger_app.js` ✅ (ya configurado)
- **Versión de Node.js**: 20.x ✅ (ya configurado)
- **Modo**: Production

### 5. Instalar/actualizar dependencias
En el terminal SSH o en cPanel:
```bash
cd /home/trigamer/diario.trigamer.xyz
npm ci --production
```

### 6. Verificar permisos de archivos
Asegúrate de que los archivos tengan los permisos correctos:
```bash
chmod 644 passenger_app.js
chmod -R 644 src/
chmod 644 package.json
```

### 7. Reiniciar la aplicación Passenger
1. En **cPanel > Setup Node.js App**
2. Busca tu aplicación
3. Haz clic en **"Restart"** 
4. Verifica que el estado cambie a **"Running"**

### 8. Verificar logs de Passenger
1. En **cPanel > Logs > Error Logs**
2. Busca errores relacionados con:
   - `passenger`
   - `node`
   - `diario.trigamer.xyz`

## 🔍 VERIFICACIONES ESPECÍFICAS PARA PASSENGER

### Probar endpoints:
1. `https://diario.trigamer.xyz/health` - Health check básico
2. `https://diario.trigamer.xyz/api/v1/status` - Diagnóstico detallado
3. `https://diario.trigamer.xyz/api/v1/docs` - Documentación de API

### Verificar que Passenger esté funcionando:
```bash
# En SSH, verificar procesos de Passenger
ps aux | grep passenger
ps aux | grep node
```

## 🚨 PROBLEMAS COMUNES CON PASSENGER

### Problema 1: Aplicación no inicia
**Síntomas**: Error 503 inmediato
**Solución**:
1. Verifica que `passenger_app.js` exista y tenga permisos correctos
2. Revisa los logs de error de cPanel
3. Asegúrate de que todas las dependencias estén instaladas

### Problema 2: Error de base de datos
**Síntomas**: Error 500 después de unos segundos
**Solución**:
1. Verifica las credenciales de BD en las variables de entorno
2. Asegúrate de que la base de datos esté creada
3. Verifica que el usuario de BD tenga permisos

### Problema 3: Memoria insuficiente
**Síntomas**: Aplicación se cierra inesperadamente
**Solución**:
1. Reduce el límite de memoria en `passenger_app.js`
2. Desactiva funciones no esenciales (RSS, etc.)
3. Considera actualizar tu plan de hosting

## 🆘 MODO DE EMERGENCIA PARA PASSENGER

Si la aplicación principal no funciona, puedes usar el servidor de emergencia:

1. En **cPanel > Setup Node.js App**, cambia el archivo de inicio a:
   ```
   emergency_start.js
   ```

2. Reinicia la aplicación

3. Verifica que funcione visitando:
   ```
   https://diario.trigamer.xyz/health
   ```

## 📋 CHECKLIST FINAL

- [ ] Variables de entorno configuradas en cPanel
- [ ] Dependencias instaladas (`npm ci --production`)
- [ ] Permisos de archivos correctos
- [ ] Aplicación reiniciada en cPanel
- [ ] Logs revisados sin errores críticos
- [ ] Endpoints de prueba funcionando

## 🔧 COMANDOS ÚTILES PARA PASSENGER

```bash
# Verificar estado de la aplicación
node check_passenger_status.js

# Reinstalar dependencias
npm ci --production

# Verificar logs en tiempo real (si tienes acceso SSH)
tail -f ~/logs/diario.trigamer.xyz_error.log

# Verificar procesos de Node.js
ps aux | grep node
```

## 📞 INFORMACIÓN PARA SOPORTE TÉCNICO

Si necesitas contactar al soporte de tu hosting, proporciona:

1. **Configuración actual**:
   - Hosting: CloudLinux con Passenger
   - Node.js: Versión 20
   - Directorio: `/home/trigamer/diario.trigamer.xyz`

2. **Logs específicos**:
   - Resultado de `check_passenger_status.js`
   - Logs de error de cPanel
   - Estado de la aplicación en Setup Node.js App

3. **Error específico**: 503 Service Unavailable en aplicación Node.js con Passenger 